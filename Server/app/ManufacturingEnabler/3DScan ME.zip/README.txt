To launch the 3DScan Enabler, first execute the following command : 

==> docker-compose build

Then, to launch the Enabler, execute the following command :

==> docker-compose up
