exports.dbType= 'mysql';
exports.host= '159.84.143.247';
exports.port= '3306';
exports.user= 'root';
exports.password= 'vf-OS@2019Dev';
exports.databaseSchema= 'vapp1';